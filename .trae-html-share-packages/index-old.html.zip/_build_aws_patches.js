// Builds the two AWS patch files consumed by apply_update.js patch.
//  aws-retirement-patch.json : lifecycle + retirementDate (from aws-model-retirement.json)
//  aws-api-patch.json        : api {rt, mt} (from aws-model-runtime&mantle.json)
const fs = require('fs');

const models = JSON.parse(fs.readFileSync('aws-models.json', 'utf8'));
const retirement = JSON.parse(fs.readFileSync('aws-model-retirement.json', 'utf8'));
const runtime = JSON.parse(fs.readFileSync('aws-model-runtime&mantle.json', 'utf8'));

const nameAlias = {
  // retirement doc uses lowercase "v2"; the region matrix keeps Bedrock's "V2:0" suffix
  'Claude 3.5 Sonnet v2': 'Claude 3.5 Sonnet V2:0',
};
const groupAlias = {
  'Luma AI': 'Luma',
};
const byName = new Map(models.map((m) => [m.g + '|' + m.n, m]));
const iso = (v) => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);

const updates = [];
const unmatched = [];
for (const r of retirement.models) {
  const n = nameAlias[r.model_name] || r.model_name;
  const key = r.provider + '|' + n;
  if (!byName.has(key)) { unmatched.push(key); continue; }
  const eols = r.region_groups.map((g) => iso(g.eol_date)).filter(Boolean).sort();
  const legacies = r.region_groups.map((g) => iso(g.legacy_date)).filter(Boolean).sort();
  const set = {};
  if (eols.length) { set.lifecycle = 'EOL'; set.retirementDate = eols[0]; }
  else if (legacies.length) { set.lifecycle = 'Legacy'; set.retirementDate = legacies[0]; }
  else continue;
  updates.push({ match: { g: r.provider, n }, set });
}

const apiUpdates = [];
const apiUnmatched = [];
for (const p of runtime.providers) {
  const g = groupAlias[p.provider] || p.provider;
  for (const m of p.models) {
    const key = g + '|' + m.model_name;
    if (!byName.has(key)) { apiUnmatched.push(key); continue; }
    apiUpdates.push({ match: { g, n: m.model_name }, set: { api: { rt: m.bedrock_runtime, mt: m.bedrock_mantle } } });
  }
}

fs.writeFileSync('aws-retirement-patch.json', JSON.stringify({ matchKeys: ['g', 'n'], updates }, null, 2));
fs.writeFileSync('aws-api-patch.json', JSON.stringify({ matchKeys: ['g', 'n'], updates: apiUpdates }, null, 2));
console.log('retirement updates', updates.length, 'unmatched', unmatched.length, unmatched.join(', '));
console.log('api updates', apiUpdates.length, 'unmatched', apiUnmatched.length, apiUnmatched.join(', '));
