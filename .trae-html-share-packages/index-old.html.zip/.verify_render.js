// Scratch render-check: load index-new.html in jsdom, exercise provider switch,
// all 4 view tabs, language toggle and theme toggle, and assert the page renders
// real content with no uncaught errors.
const fs = require('fs');
const { JSDOM } = require('jsdom');

const file = process.argv[2] || 'index-new.html';
const html = fs.readFileSync(file, 'utf8');
const errors = [];

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(win) {
    win.addEventListener('error', (e) => errors.push('window.error: ' + (e.error && e.error.stack || e.message)));
    win.console.error = (...a) => errors.push('console.error: ' + a.map(String).join(' '));
  },
});
const { window } = dom;
const document = window.document;
const $ = (id) => document.getElementById(id);

function stageInfo() {
  const stage = $('stage');
  const text = stage.textContent.replace(/\s+/g, ' ').trim();
  return {
    len: text.length,
    rows: stage.querySelectorAll('tr').length,
    tiles: stage.querySelectorAll('.tile, .card, .cell').length,
  };
}

setTimeout(() => {
  let fail = 0;
  const check = (label, ok, detail = '') => {
    console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? '  ' + detail : ''}`);
    if (!ok) fail++;
  };

  // --- data blob sanity (independent of rendering) ---
  const data = JSON.parse($('data').textContent);
  const byId = Object.fromEntries(data.providers.map((p) => [p.id, p]));
  console.log('data: ' + data.providers.map((p) => `${p.id}=${p.models.length}m/${p.regions.length}r`).join(' '));

  const sw = [...document.querySelectorAll('#switcher button')];
  check('provider switcher has 3 entries', sw.length === 3, sw.map((b) => b.dataset.id).join(','));

  // --- per provider ---
  for (const b of sw) {
    const id = b.dataset.id;
    b.click();
    const title = $('title').textContent.trim();
    const count = $('count').textContent.trim();
    const s = stageInfo();
    check(`provider ${id} renders (title/count/stage)`,
      title.length > 0 && count.length > 0 && s.len > 200,
      `title="${title}" count="${count}" stageChars=${s.len} rows=${s.rows}`);
    // switch through every tab
    for (const view of ['region', 'compare', 'model', 'matrix']) {
      const tab = document.querySelector(`.tab[data-view="${view}"]`);
      tab.click();
      const ts = stageInfo();
      check(`  ${id} / ${view} view renders`, ts.len > 100, `stageChars=${ts.len} rows=${ts.rows}`);
    }
    document.querySelector('.tab[data-view="region"]').click();
  }

  // --- language toggle ---
  $('switcher').querySelector('button').click();
  const before = $('title').textContent.trim();
  $('langToggle').click();
  const after = $('title').textContent.trim();
  check('language toggle changes UI copy', before !== after && /[\u4e00-\u9fa5]/.test(after), `"${before}" -> "${after}"`);
  $('langToggle').click();

  // --- theme toggle ---
  const root = document.getElementById('htmlRoot');
  const beforeTheme = root.className;
  $('themeToggle').click();
  check('theme toggle flips class', root.className !== beforeTheme, `"${beforeTheme}" -> "${root.className}"`);

  check('no uncaught errors / console.error', errors.length === 0, errors.slice(0, 5).join(' | '));

  console.log(fail === 0 ? '\nRENDER CHECK: ALL PASS' : `\nRENDER CHECK: ${fail} FAILURE(S)`);
  process.exit(fail === 0 ? 0 : 1);
}, 800);
