const fs = require('fs');
const { JSDOM, VirtualConsole } = require('/workspace/node_modules/jsdom');

const file = process.argv[2] || 'index.html';
const html = fs.readFileSync('/workspace/' + file, 'utf8');
const errors = [];

const vc = new VirtualConsole();
vc.on('jsdomError', (e) => errors.push('jsdomError: ' + (e && e.message)));
vc.on('error', (...a) => errors.push('console.error: ' + a.map(String).join(' ')));
vc.on('warn', () => {});
vc.on('log', () => {});
vc.on('info', () => {});

const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc });
const { window } = dom;
const doc = window.document;

function report(label) {
  const stage = doc.getElementById('stage');
  const count = doc.getElementById('count');
  const len = stage ? stage.innerHTML.length : -1;
  return `${label}: stage=${len} count="${count ? count.textContent.trim() : '?'}"`;
}

const lines = [];
lines.push('switcher buttons: ' + (doc.getElementById('switcher') || { children: [] }).children.length);
lines.push(report('initial'));

const provs = [...doc.querySelectorAll('#switcher > *')];
provs.forEach((b, i) => {
  b.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  lines.push(report('provider#' + i + '(' + b.textContent.trim() + ')'));
});

[...doc.querySelectorAll('.tab')].forEach((t) => {
  t.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  lines.push(report('view=' + t.dataset.view));
});

['themeToggle', 'langToggle'].forEach((id) => {
  const el = doc.getElementById(id);
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  lines.push('toggled ' + id + ' -> html.class="' + doc.getElementById('htmlRoot').className + '" title="' + doc.title + '"');
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
});

const badges = doc.querySelectorAll('#stage [class*="badge"]').length;
lines.push('badge nodes in stage: ' + badges);

console.log(lines.join('\n'));
if (errors.length) {
  console.log('--- ERRORS (' + errors.length + ') ---');
  console.log(errors.slice(0, 20).join('\n'));
  process.exitCode = 1;
} else {
  console.log('--- no JS errors ---');
}
