const fs = require('fs');
const { JSDOM, VirtualConsole } = require('jsdom');

const file = process.argv[2];
const html = fs.readFileSync(file, 'utf8');
const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', (e) => errors.push(e.message));
vc.on('error', (m) => errors.push(String(m)));

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  url: 'https://example.com/',
  virtualConsole: vc,
});
const d = dom.window.document;

function snapshot(label) {
  const text = d.body.textContent.replace(/\s+/g, ' ');
  console.log(`[${label}] tr=${d.querySelectorAll('tr').length} tabs=${d.querySelectorAll('.tab').length} chips=${d.querySelectorAll('.chip').length} count="${(d.querySelector('#count') || {}).textContent || ''}" textLen=${text.length}`);
}

setTimeout(() => {
  snapshot('initial');
  const lt = d.querySelector('#langToggle');
  if (lt) { lt.click(); snapshot('after-lang-click'); lt.click(); }
  const tt = d.querySelector('#themeToggle');
  if (tt) { tt.click(); console.log('theme class after toggle:', d.documentElement.className || '(none)'); tt.click(); }
  const tabs = [...d.querySelectorAll('[data-view], [data-p]')];
  console.log('view/provider tab elements:', tabs.length);
  for (const t of tabs.slice(0, 8)) { try { t.click(); } catch (e) { errors.push('click: ' + e.message); } }
  snapshot('after-tabs');
  console.log('errors:', errors.length ? errors.slice(0, 5) : 'none');
  process.exit(errors.length ? 1 : 0);
}, 800);
