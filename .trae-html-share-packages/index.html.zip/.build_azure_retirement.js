const fs = require('fs');
const HTML = '/tmp/azure-retirement.html';
const SOURCE = 'https://learn.microsoft.com/en-us/azure/foundry/openai/concepts/model-retirement-schedule';
const OUT = '/workspace/azure-model-retirement.json';

function cellText(c) {
  return c
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function nullish(v) {
  if (v === undefined || v === null) return null;
  const t = cellText(v);
  if (t === '' || t === '-' || t === '--' || t === '—' || t === '–' || /^n\/a$/i.test(t)) return null;
  return t;
}

function extractTables(html) {
  const headings = [];
  const headingRe = /<h[2-4][^>]*>([\s\S]*?)<\/h[2-4]>/g;
  let hm;
  while ((hm = headingRe.exec(html))) {
    headings.push({ pos: hm.index, text: cellText(hm[1]) });
  }
  function nearestHeading(pos) {
    let nearest = null;
    for (const h of headings) {
      if (h.pos < pos) nearest = h;
      else break;
    }
    return nearest ? nearest.text : null;
  }

  const tables = [];
  const tableRe = /<table[\s\S]*?<\/table>/g;
  let m;
  while ((m = tableRe.exec(html))) {
    const rows = [...m[0].matchAll(/<tr[\s\S]*?<\/tr>/g)].map((r) =>
      [...r[0].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].map((c) => cellText(c[1]))
    );
    tables.push({ index: tables.length, headingBefore: nearestHeading(m.index), rows });
  }
  return tables;
}

const tables = extractTables(fs.readFileSync(HTML, 'utf8'));
const sections = [];
const issues = [];
const nonIsoDates = [];

for (const t of tables) {
  const header = (t.rows[0] || []).map((h) => h.toUpperCase());
  const idx = {};
  header.forEach((h, i) => {
    if (h === 'MODEL') idx.model = i;
    if (h === 'VERSION') idx.version = i;
    if (h === 'LIFECYCLE') idx.lifecycle = i;
    if (h === 'RETIREMENT DATE') idx.retirement = i;
    if (h === 'REPLACEMENT') idx.replacement = i;
  });
  if (idx.model === undefined || idx.lifecycle === undefined || idx.retirement === undefined) {
    issues.push(`skipped table ${t.index} (heading "${t.headingBefore}") -- header: ${header.join(' | ')}`);
    continue;
  }
  const provider = t.headingBefore || 'UNKNOWN';
  const models = [];
  for (let i = 1; i < t.rows.length; i++) {
    const row = t.rows[i];
    const model = nullish(row[idx.model]);
    if (!model) {
      issues.push(`table ${t.index} row ${i}: empty model name, skipped`);
      continue;
    }
    const retirement = nullish(row[idx.retirement]);
    if (retirement && !/^\d{4}-\d{2}-\d{2}$/.test(retirement)) nonIsoDates.push(`${provider}|${model}|${retirement}`);
    models.push({
      model,
      version: idx.version !== undefined ? nullish(row[idx.version]) : null,
      lifecycle: idx.lifecycle !== undefined ? nullish(row[idx.lifecycle]) : null,
      retirement_date: retirement,
      replacement: idx.replacement !== undefined ? nullish(row[idx.replacement]) : null
    });
  }
  sections.push({ category: provider, provider, models });
}

fs.writeFileSync(OUT, JSON.stringify({ source: SOURCE, sections }, null, 2));
console.log('sections:', sections.length);
console.log('models:', sections.reduce((a, s) => a + s.models.length, 0));
const lifecycles = [...new Set(sections.flatMap((s) => s.models.map((m) => m.lifecycle)))];
console.log('lifecycles:', lifecycles.join(' | '));
if (nonIsoDates.length) console.log('non-ISO retirement dates (' + nonIsoDates.length + '):\n  ' + nonIsoDates.join('\n  '));
if (issues.length) console.log('issues (' + issues.length + '):\n  ' + issues.join('\n  '));
