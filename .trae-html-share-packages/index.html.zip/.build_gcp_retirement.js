const fs = require('fs');
const HTML = '/tmp/gcp-versions.html';
const SOURCE = 'https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/model-versions';
const OUT = '/workspace/vertex-model-retirement.json';

function cellText(c) {
  return c
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function extractTables(html) {
  const headings = [];
  const headingRe = /<h[2-4][^>]*>([\s\S]*?)<\/h[2-4]>/g;
  let hm;
  while ((hm = headingRe.exec(html))) headings.push({ pos: hm.index, text: cellText(hm[1]) });
  function nearestHeading(pos) {
    let nearest = null;
    for (const h of headings) {
      if (h.pos < pos) nearest = h;
      else break;
    }
    return nearest ? nearest.text : null;
  }
  const tables = [];
  const tableRe = /<table[\s\S]*?<\/table>/g;
  let m;
  while ((m = tableRe.exec(html))) {
    const rows = [...m[0].matchAll(/<tr[\s\S]*?<\/tr>/g)].map((r) =>
      [...r[0].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].map((c) => cellText(c[1]))
    );
    tables.push({ index: tables.length, headingBefore: nearestHeading(m.index), rows });
  }
  return tables;
}

const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

// "July 21, 2026" -> 2026-07-21 ; "May 2023" -> 2023-05 ; anything else -> null (kept as a *_note)
function parseDate(raw) {
  const t = (raw || '').replace(/[*\u00a0]/g, ' ').trim();
  if (!t) return null;
  let m = t.match(/^([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})$/);
  if (m) {
    const mo = MONTHS.indexOf(m[1].toLowerCase());
    if (mo >= 0) return `${m[3]}-${String(mo + 1).padStart(2, '0')}-${String(+m[2]).padStart(2, '0')}`;
  }
  m = t.match(/^([A-Za-z]+)\s+(\d{4})$/);
  if (m) {
    const mo = MONTHS.indexOf(m[1].toLowerCase());
    if (mo >= 0) return `${m[2]}-${String(mo + 1).padStart(2, '0')}`;
  }
  return null;
}

function dateField(raw) {
  const t = (raw || '').replace(/\s*\*\s*$/, '').trim();
  if (!t || t === '-' || t === '—') return { date: null, note: null };
  const iso = parseDate(t);
  return iso ? { date: iso, note: null } : { date: null, note: t };
}

const SECTION_ALIAS = { 'The following table lists the retired models (click to expand)': 'Retired models' };

const tables = extractTables(fs.readFileSync(HTML, 'utf8'));
const sections = [];
const issues = [];

for (const t of tables) {
  const header = (t.rows[0] || []).map((h) => h.toUpperCase());
  const idx = {};
  header.forEach((h, i) => {
    if (/^MODEL ID/.test(h)) idx.model = i;
    if (/^RELEASE DATE/.test(h)) idx.release = i;
    if (/^RETIREMENT DATE/.test(h)) idx.retirement = i;
    if (/^REPLACEMENT MODEL/.test(h) || /^RECOMMENDED UPGRADE/.test(h)) idx.replacement = i;
  });
  if (idx.model === undefined || idx.release === undefined || idx.retirement === undefined) {
    issues.push(`skipped table ${t.index} (heading "${t.headingBefore}") -- header: ${header.join(' | ')}`);
    continue;
  }
  const heading = t.headingBefore || 'UNKNOWN';
  const category = SECTION_ALIAS[heading] || heading;
  const models = [];
  for (let i = 1; i < t.rows.length; i++) {
    const row = t.rows[i];
    const model = (row[idx.model] || '').replace(/\s*\*\s*$/, '').trim();
    if (!model) continue;
    const release = dateField(row[idx.release]);
    const retirement = dateField(row[idx.retirement]);
    const replacement = (row[idx.replacement] || '').replace(/\s*\*\s*$/, '').trim() || null;
    models.push({
      model,
      release_date: release.date,
      release_date_note: release.note,
      retirement_date: retirement.date,
      retirement_date_note: retirement.note,
      replacement
    });
  }
  sections.push({ category, models });
}

fs.writeFileSync(OUT, JSON.stringify({ source: SOURCE, sections }, null, 2));
console.log('sections:', sections.length);
console.log('models:', sections.reduce((a, s) => a + s.models.length, 0));
for (const s of sections) console.log(`  [${s.category}] ${s.models.length}: ${s.models.map((m) => m.model).join(', ')}`);
if (issues.length) console.log('issues (' + issues.length + '):\n  ' + issues.join('\n  '));
