import socket, ssl

PROXY = ("127.0.0.1", 18080)

def probe(sni_host, http_host, ip, path="/token", method="POST", body=b"grant_type=authorization_code"):
    raw = socket.create_connection(PROXY, timeout=20)
    raw.sendall(f"CONNECT {ip}:443 HTTP/1.1\r\nHost: {ip}:443\r\n\r\n".encode())
    # read CONNECT response headers
    buf = b""
    while b"\r\n\r\n" not in buf:
        chunk = raw.recv(4096)
        if not chunk:
            raise RuntimeError("proxy closed during CONNECT")
        buf += chunk
    status = buf.split(b"\r\n", 1)[0].decode()
    ctx = ssl.create_default_context()
    s = ctx.wrap_socket(raw, server_hostname=sni_host)
    req = (
        f"{method} {path} HTTP/1.1\r\n"
        f"Host: {http_host}\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: {len(body)}\r\n"
        "Connection: close\r\n\r\n"
    ).encode() + body
    s.sendall(req)
    data = b""
    while True:
        chunk = s.recv(4096)
        if not chunk:
            break
        data += chunk
    s.close()
    head, _, resp = data.partition(b"\r\n\r\n")
    print(f"CONNECT {ip} SNI={sni_host} Host={http_host} [{status}] ->", head.decode(errors="replace").splitlines()[0] if head else "(empty)")
    print("  body:", resp[:200])

probe("storage.googleapis.com", "oauth2.googleapis.com", "34.3.0.27", path="/token")
probe("storage.googleapis.com", "storage.googleapis.com", "34.3.0.27", path="/", method="GET", body=b"")
