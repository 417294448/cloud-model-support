const fs = require('fs');
const oldJ = JSON.parse(fs.readFileSync('azure-model-openai-ava.json', 'utf8'));
const newJ = JSON.parse(fs.readFileSync('azure-model-openai-ava-new.json', 'utf8'));
function flatten(o) {
  const s = new Map();
  for (const d of Object.keys(o)) {
    if (d === 'source') continue;
    for (const sc of Object.keys(o[d])) {
      for (const [cat, v] of Object.entries(o[d][sc].categories || {})) {
        for (const [tab, items] of Object.entries(v.tabs || {})) {
          for (const it of items) {
            const k = d + '/' + sc + '/' + cat + '/' + tab + '/' + it.model + '@' + (it.version || '-');
            const regions = Object.entries(it.regions || {}).filter(([, x]) => x).map(([r]) => r).sort().join(',');
            s.set(k, { regions });
          }
        }
      }
    }
  }
  return s;
}
const a = flatten(oldJ), b = flatten(newJ);
const added = [...b.keys()].filter((k) => !a.has(k));
const removed = [...a.keys()].filter((k) => !b.has(k));
const changed = [...b.keys()].filter((k) => a.has(k) && a.get(k).regions !== b.get(k).regions);
console.log('old items', a.size, 'new items', b.size);
console.log('added(' + added.length + '):');
added.forEach((k) => console.log('  +', k));
console.log('removed(' + removed.length + '):');
removed.forEach((k) => console.log('  -', k));
console.log('region-changed(' + changed.length + '):');
changed.forEach((k) => console.log('  ~', k, '| old[' + a.get(k).regions + '] new[' + b.get(k).regions + ']'));
