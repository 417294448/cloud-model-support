// Headless render smoke test for the refreshed page.
const fs = require('fs');
const { JSDOM, VirtualConsole } = require('jsdom');

const file = process.argv[2] || 'index-new.html';
const html = fs.readFileSync(file, 'utf8');

const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', (e) => errors.push('jsdomError: ' + (e.stack || e.message)));
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));

const dom = new JSDOM(html, { runScripts: 'dangerously', virtualConsole: vc, pretendToBeVisual: true });
const { window } = dom;
const doc = window.document;

function stageInfo() {
  const stage = doc.getElementById('stage');
  const text = stage.textContent || '';
  return {
    len: text.length,
    tables: stage.querySelectorAll('table').length,
    rows: stage.querySelectorAll('tr').length,
    nanos: (text.match(/NaN|undefined|\[object Object\]/g) || []).length,
    first: text.replace(/\s+/g, ' ').trim().slice(0, 80),
  };
}

setTimeout(() => {
  const out = [];
  const switcher = [...doc.querySelectorAll('#switcher button')];
  out.push(`switcher buttons: ${switcher.length} (${switcher.map((b) => b.textContent.trim()).join(' | ')})`);

  const tabs = [...doc.querySelectorAll('.tab')];
  out.push(`view tabs: ${tabs.length} (${tabs.map((t) => t.textContent.trim()).join(' | ')})`);

  for (let i = 0; i < switcher.length; i++) {
    switcher[i].dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
    const pname = switcher[i].textContent.trim();
    for (let j = 0; j < tabs.length; j++) {
      [...doc.querySelectorAll('.tab')][j].dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
      const s = stageInfo();
      const tname = [...doc.querySelectorAll('.tab')][j].textContent.trim();
      out.push(`  ${pname} / ${tname}: ${s.len} chars, ${s.tables} tables, ${s.rows} rows, bad tokens=${s.nanos}`);
      if (s.nanos) out.push(`    first text: ${s.first}`);
      if (!s.len) errors.push(`empty stage for ${pname}/${tname}`);
    }
    [...doc.querySelectorAll('.tab')][0].dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  }

  const title = doc.getElementById('title');
  const count = doc.getElementById('count');
  out.push(`title: ${title ? title.textContent.trim() : '(missing)'}`);
  out.push(`count: ${count ? count.textContent.replace(/\s+/g, ' ').trim() : '(missing)'}`);

  console.log(out.join('\n'));
  console.log(errors.length ? 'ERRORS:\n' + errors.join('\n') : 'NO RENDER ERRORS');
  process.exit(errors.length ? 1 : 0);
}, 300);
