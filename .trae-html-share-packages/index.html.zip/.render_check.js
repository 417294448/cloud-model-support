// jsdom render check: loads a built index.html, drives every provider/view/filter
// combination, and fails on any uncaught error or obviously broken rendered text.
const fs = require('fs');
const { JSDOM } = require('/tmp/rendercheck/node_modules/jsdom');

const file = process.argv[2];
const html = fs.readFileSync(file, 'utf8');
const problems = [];
const info = [];

const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.test/' });
const { window } = dom;
window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }));

window.addEventListener('error', (e) => problems.push('window.error: ' + ((e.error && e.error.stack) || e.message)));
window.addEventListener('unhandledrejection', (e) => problems.push('unhandledrejection: ' + e.reason));
const origErr = window.console.error;
window.console.error = (...a) => { problems.push('console.error: ' + a.join(' ')); origErr.apply(window.console, a); };

const doc = window.document;
const $ = (s) => doc.querySelector(s);
const $$ = (s) => [...doc.querySelectorAll(s)];
const fire = (el, type) => el.dispatchEvent(new window.Event(type, { bubbles: true }));
const click = (el) => el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));

const BAD = [/undefined/, /\[object Object\]/, /\bNaN\b/, /&lt;/];

function stageCheck(label) {
  const stage = $('#stage');
  const text = stage ? stage.textContent : '';
  const htmlLen = stage ? stage.innerHTML.length : 0;
  if (!htmlLen) problems.push(`${label}: #stage is empty`);
  for (const re of BAD) if (re.test(text)) problems.push(`${label}: suspicious text in #stage (${re}) :: ${text.slice(0, 160)}`);
  return htmlLen;
}

const VIEWS = ['region', 'compare', 'model', 'matrix'];

function sweep(tag) {
  const results = [];
  window.localStorage.clear(); // each sweep starts from default filters for every provider
  for (const btn of $$('#switcher button')) {
    const id = btn.dataset.id;
    click(btn);
    for (const v of VIEWS) {
      const tab = $(`.tab[data-view="${v}"]`);
      if (!tab) { problems.push(`${tag}/${id}: missing tab ${v}`); continue; }
      click(tab);
      const len = stageCheck(`${tag}/${id}/${v}`);
      if (v === 'region' || v === 'model') {
        const body = $('#stage').textContent;
        if (body.length < 50) problems.push(`${tag}/${id}/${v}: rendered text suspiciously short (${body.length} chars)`);
      }
      results.push(`${id}/${v}=${len}`);
    }
    // filters
    click($('#lifecycleBtn'));
    click($('#diffBtn'));
    const api = $('#apiSel');
    if (api && api.options.length > 1) { api.value = api.options[1].value; fire(api, 'change'); }
    const cat = $('#catSel');
    if (cat && cat.options.length > 1) { cat.value = cat.options[1].value; fire(cat, 'change'); }
    const q = $('#q');
    q.value = 'a'; fire(q, 'input');
    stageCheck(`${tag}/${id}/filters`);
    q.value = ''; fire(q, 'input');
    click($('#lifecycleBtn'));
    click($('#diffBtn'));
    if (cat) { cat.value = ''; fire(cat, 'change'); }
    if (api) { api.value = ''; fire(api, 'change'); }
    // per-provider selectors
    for (const sel of ['#regionSel', '#regionBSel']) {
      const s = $(sel);
      if (!s || s.options.length < 2) continue;
      s.value = s.options[s.options.length - 1].value;
      fire(s, 'change');
      stageCheck(`${tag}/${id}${sel}`);
      s.value = s.options[0].value; fire(s, 'change');
    }
  }
  return results;
}

function select(id) {
  const btn = $$('#switcher button').find((b) => b.dataset.id === id);
  if (!btn) { problems.push('missing provider button: ' + id); return false; }
  click(btn);
  return true;
}

function searchIn(id, term) {
  select(id);
  click($('.tab[data-view="model"]'));
  const q = $('#q');
  q.value = term; fire(q, 'input');
  const text = $('#stage').textContent;
  q.value = ''; fire(q, 'input');
  return { text };
}

window.addEventListener('load', () => {
  try {
    if ($$('#switcher button').length !== 3) problems.push(`expected 3 provider buttons, got ${$$('#switcher button').length}`);
    info.push('en stage sizes: ' + sweep('en').join(' '));

    // i18n: toggle to Chinese and re-sweep
    click($('#langToggle'));
    info.push('zh stage sizes: ' + sweep('zh').join(' '));
    const missingKeys = $$('[data-i18n]').filter((el) => el.textContent.trim() === el.getAttribute('data-i18n')).map((el) => el.getAttribute('data-i18n'));
    if (missingKeys.length) problems.push('i18n keys not translated (text fell back to the key): ' + [...new Set(missingKeys)].join(', '));

    // theme toggle: badge colors must re-resolve, no errors
    click($('#themeToggle'));
    if (!doc.documentElement.classList.contains('light')) problems.push('theme toggle did not switch html.light on');
    sweep('light');
    click($('#themeToggle'));

    // data assertions on the freshly refreshed providers
    if (!searchIn('aws', 'Kimi K3').text.includes('Kimi K3')) problems.push('aws: new model "Kimi K3" not rendered');
    if (searchIn('aws', 'Claude Mythos Preview').text.includes('Claude Mythos Preview')) problems.push('aws: removed model "Claude Mythos Preview" still rendered');
    if (!searchIn('gcp', 'glm-4.7-flash').text.includes('glm-4.7-flash')) problems.push('gcp: new model "glm-4.7-flash" not rendered');
    if (searchIn('gcp', 'claude-opus-4-1').text.includes('claude-opus-4-1')) problems.push('gcp: removed model "claude-opus-4-1" still rendered');
    if (!searchIn('azure', 'gpt-image-1.5').text.includes('gpt-image-1.5')) problems.push('azure: model "gpt-image-1.5" not rendered');

    console.log(info.join('\n'));
    if (problems.length) { console.log('\nFAIL (' + problems.length + '):'); for (const p of problems) console.log('  - ' + p); process.exitCode = 1; }
    else console.log('\nRENDER OK: no errors; all providers x views x filters rendered cleanly.');
  } catch (e) {
    console.log('FAIL: exception during render check: ' + e.stack);
    process.exitCode = 1;
  }
});
