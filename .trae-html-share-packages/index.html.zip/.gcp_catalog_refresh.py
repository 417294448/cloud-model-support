#!/usr/bin/env python3
"""Verify the SA credential cheaply and dump the live Model Garden catalog.

Writes the fresh catalog to vertex_all_models_new.json (does NOT overwrite the
tracked cache yet) and prints only aggregate info.
"""
import json
import sys

import requests

import build_vertex_matrix as bvm

SA = "sa.json"
OLD = "vertex_all_models.json"
NEW = "vertex_all_models_new.json"

token_fn = bvm.service_account_token_fn(SA)
with open(SA, encoding="utf-8") as f:
    project = json.load(f)["project_id"]
print(f"[auth] using service account (project {project})", file=sys.stderr)

# cheap smoke call first: one page of the catalog list
tok = token_fn(30)
r = requests.get(
    "https://us-central1-aiplatform.googleapis.com/v1beta1/publishers/*/models",
    headers={"Authorization": f"Bearer {tok}", "x-goog-user-project": project},
    params={"pageSize": 1, "listAllVersions": True, "filter": "is_hf_wildcard(false)"},
    timeout=60,
)
print(f"[auth] catalog smoke call HTTP {r.status_code}", file=sys.stderr)
if r.status_code != 200:
    print(r.text[:800], file=sys.stderr)
    raise SystemExit("credential check failed")

catalog = bvm.fetch_catalog_rest(requests.Session(), token_fn, project, timeout=180)
with open(NEW, "w", encoding="utf-8") as f:
    json.dump(catalog, f, ensure_ascii=False)

old = json.load(open(OLD, encoding="utf-8"))
old_names = {e.get("name") for e in old}
new_names = {e.get("name") for e in catalog}
added = sorted(n for n in new_names - old_names if n)
removed = sorted(n for n in old_names - new_names if n)
print(f"[catalog] old={len(old)} new={len(catalog)} added={len(added)} removed={len(removed)}", file=sys.stderr)
for n in added:
    print("  +", n, file=sys.stderr)
for n in removed[:40]:
    print("  -", n, file=sys.stderr)
if len(removed) > 40:
    print(f"  ... and {len(removed) - 40} more removed", file=sys.stderr)
