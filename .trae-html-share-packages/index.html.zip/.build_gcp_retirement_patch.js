// Builds the GCP lifecycle patch.json from vertex-model-retirement.json.
// Mirrors update-gcp.js's heuristic (lines "打 lifecycle 标签"):
//   retirementDate = retirement_date (exact ISO) or retirement_date_note
//   replacement    = replacement (empty -> null)
//   lifecycle      = exact ISO date AND a non-empty replacement -> "Deprecated", else "Legacy"
// The "Retired models" section is skipped (those models are out of the catalog),
// except textembedding-gecko which is still in the catalog as v=latest
// (confirmed with the user 2026-08-23).
const fs = require('fs');

const RETIRED_BUT_TAGGED = {
  'textembedding-gecko': { lifecycle: 'Deprecated', retirementDate: '2025-05-24', replacement: 'gemini-embedding-001' }
};

const retirement = JSON.parse(fs.readFileSync(process.argv[2] || 'vertex-model-retirement.json', 'utf8'));
const outPath = process.argv[3] || '/tmp/gcp-retirement-patch.json';

const lookup = new Map();
for (const sec of retirement.sections) {
  const retired = sec.category === 'Retired models';
  for (const m of sec.models) {
    const base = m.model.split('@')[0];
    if (retired && !RETIRED_BUT_TAGGED[base]) continue;
    const retirementDate = m.retirement_date || m.retirement_date_note || null;
    const replacement = m.replacement || null;
    const isExact = /^\d{4}-\d{2}-\d{2}$/.test(m.retirement_date || '');
    const lifecycle = isExact && replacement ? 'Deprecated' : 'Legacy';
    lookup.set(base, { lifecycle, retirementDate, replacement });
  }
}
for (const [k, v] of Object.entries(RETIRED_BUT_TAGGED)) lookup.set(k, v);

const updates = [...lookup.entries()].map(([n, set]) => ({ match: { n }, set }));
fs.writeFileSync(outPath, JSON.stringify({ matchKeys: ['n'], updates }, null, 2));
console.log(`patch entries: ${updates.length} -> ${outPath}`);
const dep = updates.filter((u) => u.set.lifecycle === 'Deprecated').length;
console.log(`  Deprecated: ${dep} | Legacy: ${updates.length - dep}`);
