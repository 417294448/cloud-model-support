// Diff two Model Garden catalog dumps the same way build_vertex_matrix.py's
// dedupe_models() collapses them: one entry per (publisher, model_id), keeping
// the highest launch stage (ties broken by version string).
const fs = require('fs');

const NAME_RE = /publishers\/([^/]+)\/models\/([^/@]+)(?:@(.+))?$/;
const LAUNCH_STAGE_RANK = { GA: 3, PUBLIC_PREVIEW: 2, PRIVATE_PREVIEW: 1, EXPERIMENTAL: 0 };
const EXCLUDED_PUBLISHERS = new Set(['internal-test-google']);

function dedupe(catalog) {
  const best = new Map();
  for (const entry of catalog) {
    const m = NAME_RE.exec(entry.name || '');
    if (!m) continue;
    const publisher = m[1];
    const modelId = m[2];
    const version = m[3] || entry.versionId;
    if (EXCLUDED_PUBLISHERS.has(publisher)) continue;
    const key = publisher + '|' + modelId;
    const stage = entry.launchStage || '';
    const rank = stage in LAUNCH_STAGE_RANK ? LAUNCH_STAGE_RANK[stage] : -1;
    const cur = best.get(key);
    if (!cur || rank > cur._rank || (rank === cur._rank && (version || '') > (cur.version || ''))) {
      best.set(key, { publisher, model_id: modelId, version, launch_stage: stage, display_name: entry.displayName || modelId, _rank: rank });
    }
  }
  return best;
}

function load(p) {
  const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
  return Array.isArray(raw) ? raw : raw.models || [];
}

const oldMap = dedupe(load(process.argv[2]));
const newMap = dedupe(load(process.argv[3]));

const added = [...newMap.keys()].filter((k) => !oldMap.has(k));
const removed = [...oldMap.keys()].filter((k) => !newMap.has(k));
const restaged = [...newMap.keys()].filter((k) => {
  if (!oldMap.has(k)) return false;
  const a = oldMap.get(k), b = newMap.get(k);
  return a.version !== b.version || a.launch_stage !== b.launch_stage;
});

console.log(`unique (publisher,model_id): ${oldMap.size} -> ${newMap.size}`);
console.log(`added (${added.length}):` + (added.length ? '\n  ' + added.map((k) => `${newMap.get(k).publisher} / ${newMap.get(k).model_id} [${newMap.get(k).launch_stage || 'no-stage'}] v=${newMap.get(k).version}`).join('\n  ') : ' none'));
console.log(`removed (${removed.length}):` + (removed.length ? '\n  ' + removed.map((k) => `${oldMap.get(k).publisher} / ${oldMap.get(k).model_id} [${oldMap.get(k).launch_stage || 'no-stage'}] v=${oldMap.get(k).version}`).join('\n  ') : ' none'));
console.log(`version/stage changed (${restaged.length}):` + (restaged.length ? '\n  ' + restaged.map((k) => `${k}: v=${oldMap.get(k).version || '-'}[${oldMap.get(k).launch_stage || '-'}] -> v=${newMap.get(k).version || '-'}[${newMap.get(k).launch_stage || '-'}]`).join('\n  ') : ' none'));
