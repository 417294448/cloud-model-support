"""Fetch the Model Garden catalog via the service-account REST path and save it.

Reuses build_vertex_matrix.py's own auth + catalog functions so the output is
identical to what `--service-account <sa> --catalog-file <out>` would consume.
"""
import importlib.util
import json
import sys

import requests

spec = importlib.util.spec_from_file_location("bvm", "build_vertex_matrix.py")
bvm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bvm)

sa_path = sys.argv[1]
out_path = sys.argv[2]

token_fn = bvm.service_account_token_fn(sa_path)
with open(sa_path, encoding="utf-8") as f:
    project = json.load(f)["project_id"]

catalog = bvm.fetch_catalog_rest(requests.Session(), token_fn, project, timeout=180)
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(catalog, f, ensure_ascii=False, indent=2)
print(f"wrote {out_path}: {len(catalog)} entries", file=sys.stderr)
