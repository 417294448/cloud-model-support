const fs = require('fs');
const oldJ = JSON.parse(fs.readFileSync('/workspace/azure-model-openai-ava.json', 'utf8'));
const newJ = JSON.parse(fs.readFileSync('/tmp/azure-openai-ava-built.json', 'utf8'));
function flat(j) {
  const m = new Map();
  for (const grp of ['standard', 'provisioned', 'batch']) {
    if (!j[grp]) continue;
    for (const kind of Object.keys(j[grp])) {
      const cats = j[grp][kind].categories || {};
      for (const cat of Object.keys(cats)) {
        const tb = cats[cat].tabs || {};
        for (const tab of Object.keys(tb)) for (const e of tb[tab]) m.set(`${grp}.${kind}|${cat}|${tab}|${e.model}|${e.version}`, e.regions);
      }
    }
  }
  return m;
}
const A = flat(oldJ), B = flat(newJ);
let onlyCol = 0, realFlips = 0;
const examples = [];
for (const k of B.keys()) {
  if (!A.has(k)) continue;
  const a = A.get(k), b = B.get(k);
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  const diffs = [...keys].filter(x => (a[x] || false) !== (b[x] || false));
  const nonNew = diffs.filter(x => x !== 'northeurope');
  if (diffs.length && nonNew.length === 0) onlyCol++;
  else if (nonNew.length) {
    realFlips++;
    if (examples.length < 15) examples.push(`${k}: ${nonNew.map(x => `${x} ${a[x] || false}->${b[x] || false}`).join(', ')}`);
  }
}
console.log(`entries changed only by new 'northeurope' column: ${onlyCol}`);
console.log(`entries with real boolean flips: ${realFlips}`);
examples.forEach(e => console.log('  ' + e));
