// Compact structural summary of fetched AWS docs pages (avoids dumping all rows).
const fs = require('fs');
const files = process.argv.slice(2);
function cellText(c) {
  c = c.replace(/<img[^>]*icon-yes[^>]*>/gi, 'YES').replace(/<img[^>]*icon-no[^>]*>/gi, 'NO');
  return c.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}
for (const f of files) {
  const html = fs.readFileSync(f, 'utf8');
  const tables = [];
  const tableRe = /<table[\s\S]*?<\/table>/g;
  let m;
  const headings = [];
  const headingRe = /<h[2-4][^>]*>([\s\S]*?)<\/h[2-4]>/g;
  let hm;
  while ((hm = headingRe.exec(html))) headings.push({ pos: hm.index, text: cellText(hm[1]) });
  function nearestHeading(pos) { let n = null; for (const h of headings) { if (h.pos < pos) n = h; else break; } return n ? n.text : null; }
  while ((m = tableRe.exec(html))) {
    const rows = [...m[0].matchAll(/<tr[\s\S]*?<\/tr>/g)].map((r) => [...r[0].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].map((c) => cellText(c[1])));
    const capM = m[0].match(/<caption[^>]*>([\s\S]*?)<\/caption>/i);
    tables.push({ heading: nearestHeading(m.index), caption: capM ? cellText(capM[1]).slice(0, 60) : null, rows: rows.length, header: rows[0] });
  }
  console.log(`\n===== ${f} : ${tables.length} tables =====`);
  const byKey = {};
  for (const t of tables) {
    const k = JSON.stringify(t.header) + ' || heading=' + t.heading;
    byKey[k] = byKey[k] || { count: 0, rows: 0 };
    byKey[k].count++;
    byKey[k].rows += t.rows;
  }
  for (const [k, v] of Object.entries(byKey)) {
    console.log(`  [${v.count} tables, ${v.rows} rows] ${k}`);
  }
}
