const fs = require('fs');
const html = fs.readFileSync('/tmp/aws-region.html', 'utf8');
const tableRe = /<table[\s\S]*?<\/table>/g;
let m, i = -1;
while ((m = tableRe.exec(html))) {
  i++;
  if (/Claude Sonnet 4<\/a>|>Claude Sonnet 4<\/caption>|Claude Sonnet 4<\/a>/.test(m[0]) && i === 26 || i === 26) {
    console.log('=== raw table 26 (should be Claude Sonnet 4) ===');
    console.log(m[0].slice(0, 2600).replace(/></g, '>\n<'));
    break;
  }
}
