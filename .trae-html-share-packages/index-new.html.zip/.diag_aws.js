const fs = require('fs');
const html = fs.readFileSync('/tmp/aws-region.html', 'utf8');
function cellText(c) {
  c = c.replace(/<img[^>]*icon-yes[^>]*>/gi, 'YES').replace(/<img[^>]*icon-no[^>]*>/gi, 'NO');
  return c.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}
const tables = [];
const tableRe = /<table[\s\S]*?<\/table>/g;
let m;
while ((m = tableRe.exec(html))) {
  const rows = [...m[0].matchAll(/<tr[\s\S]*?<\/tr>/g)].map((r) =>
    [...r[0].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].map((c) => cellText(c[1]))
  );
  const capm = m[0].match(/<caption[^>]*>([\s\S]*?)<\/caption>/i);
  tables.push({ index: tables.length, caption: capm ? cellText(capm[1]) : null, rows });
}
for (const t of tables) {
  if (t.rows[0] && JSON.stringify(t.rows[0]) === JSON.stringify(['Region', 'In-Region', 'Geo', 'Global'])) {
    console.log('FOUND index', t.index, 'caption', JSON.stringify(t.caption));
    t.rows.forEach((r, i) => console.log(' row', i, JSON.stringify(r)));
  }
}
// also list captions for tables 24-33 to see neighbors of the malformed one
console.log('\nneighbors 22-34:');
tables.filter(t => t.index >= 22 && t.index <= 34).forEach(t => console.log(t.index, JSON.stringify(t.caption), 'header0=', JSON.stringify(t.rows[0])));
