const fs = require('fs');

function cellText(c) {
  c = c.replace(/<img[^>]*icon-yes[^>]*>/gi, 'YES').replace(/<img[^>]*icon-no[^>]*>/gi, 'NO');
  return c.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim();
}

// 1) endpoints table 0
{
  const html = fs.readFileSync('/tmp/aws-endpoints.html', 'utf8');
  const tables = [...html.matchAll(/<table[\s\S]*?<\/table>/g)];
  const rows = [...tables[0][0].matchAll(/<tr[\s\S]*?<\/tr>/g)].map((r) =>
    [...r[0].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].map((c) => cellText(c[1]))
  );
  console.log('=== endpoints table0 ===');
  rows.forEach(r => console.log(JSON.stringify(r)));
}

// 2) region page: paragraph text mentioning mantle
{
  const html = fs.readFileSync('/tmp/aws-region.html', 'utf8');
  const paras = [...html.matchAll(/<(p|li)[^>]*>([\s\S]*?)<\/\1>/g)].map(m => cellText(m[2]));
  const hits = paras.filter(p => /mantle/i.test(p));
  console.log('\n=== region page text mentioning mantle (' + hits.length + ') ===');
  // dedupe
  [...new Set(hits)].slice(0, 12).forEach(p => console.log('-', p.slice(0, 400)));
}

// 3) index.html aws caps
{
  const html = fs.readFileSync('/workspace/index.html', 'utf8');
  const prefix = '<script id="data" type="application/json">';
  const start = html.indexOf(prefix) + prefix.length;
  const end = html.indexOf('</script>', start);
  const data = JSON.parse(html.slice(start, end));
  const aws = data.providers.find(p => p.id === 'aws');
  console.log('\n=== aws provider meta ===');
  console.log('axisLabel', aws.axisLabel, '| groupLabel', aws.groupLabel, '| chipMode', aws.chipMode, '| generated', aws.generated);
  console.log('caps', JSON.stringify(aws.caps, null, 0));
  console.log('regions count', aws.regions.length, '| groups', aws.groups.length, '| models', aws.models.length);
  const sample = aws.models.filter(m => ['Claude Haiku 4.5','GPT-5.4','Claude Opus 4.8'].includes(m.n));
  console.log('samples', JSON.stringify(sample.map(m => ({ g: m.g, n: m.n, s: m.s })).slice(0, 3)));
}
